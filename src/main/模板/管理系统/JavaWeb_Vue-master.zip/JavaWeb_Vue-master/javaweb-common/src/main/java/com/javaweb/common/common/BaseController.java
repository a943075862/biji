package com.javaweb.common.common;

public class BaseController {
}
