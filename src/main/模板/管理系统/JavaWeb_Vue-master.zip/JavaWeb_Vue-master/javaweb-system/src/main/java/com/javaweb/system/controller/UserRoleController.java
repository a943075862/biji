package com.javaweb.system.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import com.javaweb.common.common.BaseController;

/**
 * <p>
 * 人员角色表 前端控制器
 * </p>
 *
 * @author 鲲鹏
 * @since 2020-03-26
 */
@RestController
@RequestMapping("/user-role")
public class UserRoleController extends BaseController {

}
