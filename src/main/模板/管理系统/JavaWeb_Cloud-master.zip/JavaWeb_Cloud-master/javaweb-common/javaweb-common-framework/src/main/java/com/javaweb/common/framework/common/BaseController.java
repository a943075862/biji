package com.javaweb.common.framework.common;

/**
 * 基类控制器
 */
public class BaseController {

}
